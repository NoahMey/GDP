package generics;

// Hier kommt Ihre Implementation der Klasse Pair hin